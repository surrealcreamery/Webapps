/**
 * Orders API Lambda
 * Fetches order data from DynamoDB for the admin dashboard
 * Supports healing/re-processing orders
 */

import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, ScanCommand, UpdateCommand, GetCommand } from '@aws-sdk/lib-dynamodb';

const ddbClient = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(ddbClient);
const TABLE_NAME = 'surreal-orders';

// Shopify API config
const SHOPIFY_STORE_DOMAIN = process.env.SHOPIFY_STORE_DOMAIN;
const SHOPIFY_ACCESS_TOKEN = process.env.SHOPIFY_ACCESS_TOKEN;

// CORS headers
const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

/**
 * Fetch order from Shopify Admin API
 */
async function fetchShopifyOrder(orderId) {
  if (!SHOPIFY_STORE_DOMAIN || !SHOPIFY_ACCESS_TOKEN) {
    throw new Error('Shopify credentials not configured');
  }

  const url = `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/orders/${orderId}.json`;
  const response = await fetch(url, {
    headers: {
      'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch order from Shopify: ${response.status}`);
  }

  const data = await response.json();
  return data.order;
}

/**
 * Fetch location details from Shopify
 */
async function fetchLocationName(locationId) {
  if (!locationId || !SHOPIFY_STORE_DOMAIN || !SHOPIFY_ACCESS_TOKEN) {
    return null;
  }

  try {
    const url = `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/locations/${locationId}.json`;
    const response = await fetch(url, {
      headers: {
        'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN,
      },
    });

    if (response.ok) {
      const data = await response.json();
      return data.location?.name || null;
    }
  } catch (error) {
    console.error('Error fetching location:', error);
  }
  return null;
}

/**
 * Get fulfillment location ID from Shopify order
 */
async function getFulfillmentLocationId(orderId) {
  if (!SHOPIFY_STORE_DOMAIN || !SHOPIFY_ACCESS_TOKEN) {
    return null;
  }

  try {
    const url = `https://${SHOPIFY_STORE_DOMAIN}/admin/api/2024-01/orders/${orderId}/fulfillment_orders.json`;
    const response = await fetch(url, {
      headers: {
        'X-Shopify-Access-Token': SHOPIFY_ACCESS_TOKEN,
      },
    });

    if (response.ok) {
      const data = await response.json();
      const fulfillmentOrders = data.fulfillment_orders || [];
      if (fulfillmentOrders.length > 0) {
        return fulfillmentOrders[0].assigned_location_id;
      }
    }
  } catch (error) {
    console.error('Error fetching fulfillment orders:', error);
  }
  return null;
}

/**
 * Heal/re-process an order
 */
async function healOrder(orderId) {
  console.log(`Healing order: ${orderId}`);

  // Fetch order from Shopify
  const shopifyOrder = await fetchShopifyOrder(orderId);
  if (!shopifyOrder) {
    throw new Error('Order not found in Shopify');
  }

  // Get fulfillment location and name
  const fulfillmentLocationId = await getFulfillmentLocationId(orderId);
  let locationName = null;
  if (fulfillmentLocationId) {
    locationName = await fetchLocationName(fulfillmentLocationId);
  }

  // Determine delivery type from shipping lines
  const shippingLine = shopifyOrder.shipping_lines?.[0];
  const shippingMethod = shippingLine?.title || shippingLine?.code || '';
  const isLocalDelivery = shippingMethod.toLowerCase().includes('local') ||
                          shippingMethod.toLowerCase().includes('delivery') ||
                          shippingLine?.source === 'shopify-local-delivery';
  const deliveryType = isLocalDelivery ? 'local' : 'shipping';

  // Calculate subtotal and shipping price
  const subtotalPrice = shopifyOrder.line_items?.reduce((sum, item) =>
    sum + (parseFloat(item.price) * item.quantity), 0) || 0;
  const shippingPrice = parseFloat(shippingLine?.price || 0);

  // Update DynamoDB record
  const updateParams = {
    TableName: TABLE_NAME,
    Key: {
      pk: `ORDER#${orderId}`,
      sk: `SHOPIFY#${orderId}`,
    },
    UpdateExpression: `SET
      #locationName = :locationName,
      #shippingMethod = :shippingMethod,
      #deliveryType = :deliveryType,
      #subtotalPrice = :subtotalPrice,
      #shippingPrice = :shippingPrice,
      #updatedAt = :updatedAt,
      #healedAt = :healedAt`,
    ExpressionAttributeNames: {
      '#locationName': 'locationName',
      '#shippingMethod': 'shippingMethod',
      '#deliveryType': 'deliveryType',
      '#subtotalPrice': 'subtotalPrice',
      '#shippingPrice': 'shippingPrice',
      '#updatedAt': 'updatedAt',
      '#healedAt': 'healedAt',
    },
    ExpressionAttributeValues: {
      ':locationName': locationName || 'Unknown',
      ':shippingMethod': shippingMethod,
      ':deliveryType': deliveryType,
      ':subtotalPrice': subtotalPrice,
      ':shippingPrice': shippingPrice,
      ':updatedAt': new Date().toISOString(),
      ':healedAt': new Date().toISOString(),
    },
    ReturnValues: 'ALL_NEW',
  };

  const result = await docClient.send(new UpdateCommand(updateParams));
  console.log('Order healed:', result.Attributes);

  return {
    orderId,
    orderNumber: shopifyOrder.order_number,
    locationName: locationName || 'Unknown',
    deliveryType,
    shippingMethod,
    subtotalPrice,
    shippingPrice,
    healedAt: new Date().toISOString(),
  };
}

/**
 * Heal multiple orders
 */
async function healOrders(orderIds) {
  const results = [];
  const errors = [];

  for (const orderId of orderIds) {
    try {
      const result = await healOrder(orderId);
      results.push(result);
    } catch (error) {
      console.error(`Failed to heal order ${orderId}:`, error);
      errors.push({ orderId, error: error.message });
    }
  }

  return { results, errors };
}

export const handler = async (event) => {
  console.log('Received event:', JSON.stringify(event));

  const method = event.requestContext?.http?.method || event.httpMethod;
  console.log('HTTP Method:', method);

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // POST - Heal orders
    if (method === 'POST') {
      console.log('Processing POST request');
      console.log('Raw body:', event.body);
      const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
      console.log('Parsed body:', JSON.stringify(body));
      const { action, orderIds, orderId } = body || {};
      console.log('Action:', action, 'OrderIds:', orderIds, 'OrderId:', orderId);

      if (action === 'heal') {
        const idsToHeal = orderIds || (orderId ? [orderId] : []);
        if (idsToHeal.length === 0) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'No order IDs provided' }),
          };
        }

        const healResults = await healOrders(idsToHeal);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            healed: healResults.results.length,
            failed: healResults.errors.length,
            results: healResults.results,
            errors: healResults.errors,
          }),
        };
      }

      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid action' }),
      };
    }

    // GET - List orders
    const params = event.queryStringParameters || {};
    const { date, locationId, status, limit = '50' } = params;

    let result;

    // Use Scan with filter - simple approach that works without specific GSIs
    const scanParams = {
      TableName: TABLE_NAME,
      Limit: parseInt(limit),
    };

    if (date) {
      scanParams.FilterExpression = '#d = :d';
      scanParams.ExpressionAttributeNames = { '#d': 'date' };
      scanParams.ExpressionAttributeValues = { ':d': date };
    }

    result = await docClient.send(new ScanCommand(scanParams));

    // Filter out error records and format response
    const orders = (result.Items || [])
      .filter(item => item.sk?.startsWith('SHOPIFY#'))
      .map(item => ({
        orderId: item.shopifyOrderId,
        orderNumber: item.orderNumber,
        orderName: item.orderName,
        squareOrderId: item.squareOrderId,
        shipdayOrderId: item.shipdayOrderId,
        customerName: item.customerName,
        customerEmail: item.customerEmail,
        customerPhone: item.customerPhone,
        shippingAddress: item.shippingAddress,
        shippingMethod: item.shippingMethod,
        deliveryType: item.deliveryType,
        lineItems: item.lineItems,
        subtotalPrice: item.subtotalPrice,
        shippingPrice: item.shippingPrice,
        totalPrice: item.totalPrice,
        grossAmount: item.grossAmount,
        transactionFee: item.transactionFee,
        netAmount: item.netAmount,
        status: item.status,
        locationName: item.locationName,
        squareLocationId: item.squareLocationId,
        createdAt: item.createdAt,
        date: item.date,
        healedAt: item.healedAt,
      }))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        orders,
        count: orders.length,
      }),
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
